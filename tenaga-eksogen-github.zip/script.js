const processes = [
  {
    id: "pelapukan",
    name: "Pelapukan",
    tag: "Penghancuran batuan",
    desc: "Penghancuran atau peruraian batuan tanpa disertai perpindahan massa batuan ke tempat lain.",
    points: [
      "Mekanik/Fisik: perubahan suhu ekstrem, pembekuan air di celah batuan, atau akar tanaman.",
      "Kimiawi: reaksi batuan dengan air, oksigen, atau asam (contoh: pelarutan batu kapur membentuk gua/karst).",
      "Organik/Biologis: aktivitas makhluk hidup seperti lumut, cacing, atau manusia."
    ]
  },
  {
    id: "erosi",
    name: "Erosi",
    tag: "Pengikisan & pengangkutan",
    desc: "Pengikisan batuan atau tanah yang disertai perpindahan/pengangkutan material oleh zat pengangkut.",
    points: [
      "Air (ablasi): aliran sungai atau hujan membentuk jurang atau lembah V.",
      "Angin (deflasi/korasi): angin kencang membentuk batuan jamur (mushroom rock).",
      "Gelombang laut (abrasi): hantaman ombak membentuk tebing terjal atau gua pantai.",
      "Gletser (glasial): gerakan es di pegunungan tinggi membentuk lembah U."
    ]
  },
  {
    id: "sedimentasi",
    name: "Sedimentasi",
    tag: "Pengendapan material",
    desc: "Pengendapan material hasil pelapukan dan erosi ketika tenaga pengangkut melemah.",
    points: [
      "Fluvial (sungai): membentuk delta, dataran banjir, atau oxbow lake.",
      "Marine (laut): membentuk pantai landai, sandbar, atau gosong pasir.",
      "Aeolis (angin): membentuk gumuk pasir (sand dunes)."
    ]
  },
  {
    id: "masswasting",
    name: "Mass Wasting",
    tag: "Gerak massa lereng",
    desc: "Perpindahan massa batuan atau tanah menuruni lereng karena pengaruh gaya gravitasi.",
    points: [
      "Contoh nyata: tanah longsor, guguran batu (rockfall), atau rayapan tanah (creep).",
      "Sering dipicu curah hujan tinggi, kemiringan lereng curam, dan berkurangnya vegetasi."
    ]
  }
];

const procButtons = document.getElementById("proc-buttons");
const procDetail = document.getElementById("proc-detail");

function renderProcess(id) {
  const item = processes.find(p => p.id === id) || processes[0];
  document.querySelectorAll(".proc-card").forEach(el => {
    el.classList.toggle("selected", el.dataset.id === item.id);
  });
  procDetail.innerHTML = `
    <h2>${item.name}</h2>
    <p>${item.desc}</p>
    <ul>${item.points.map(pt => `<li>${pt}</li>`).join("")}</ul>
  `;
}

processes.forEach((p, idx) => {
  const btn = document.createElement("div");
  btn.className = "proc-card" + (idx === 0 ? " selected" : "");
  btn.dataset.id = p.id;
  btn.innerHTML = `<h3>${p.name}</h3><span>${p.tag}</span>`;
  btn.addEventListener("click", () => renderProcess(p.id));
  procButtons.appendChild(btn);
});
renderProcess(processes[0].id);

document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
  });
});

const answers = { q1: "b", q2: "a", q3: "c" };
document.getElementById("quiz-form").addEventListener("submit", e => {
  e.preventDefault();
  let score = 0;
  for (const [q, ans] of Object.entries(answers)) {
    const chosen = document.querySelector(`input[name="${q}"]:checked`);
    if (chosen && chosen.value === ans) score++;
  }
  const res = document.getElementById("quiz-result");
  res.className = score === 3 ? "res-good" : "res-mid";
  res.textContent = `Skor kamu: ${score} dari ${Object.keys(answers).length} soal benar.`;
});
