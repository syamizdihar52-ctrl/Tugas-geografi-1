# Modul Interaktif: Tenaga Eksogen

Aplikasi web statis sederhana untuk mempelajari materi geografi **Tenaga Eksogen** (Pelapukan, Erosi, Sedimentasi, dan *Mass Wasting*), perbandingannya dengan tenaga endogen, dampak kehidupan, serta latihan kuis interaktif.

## Struktur File
- `index.html` — Struktur halaman dan konten materi
- `style.css` — Tampilan antarmuka responsif
- `script.js` — Logika tab navigasi, detail proses eksogen, dan penilaian kuis

## Cara Menjalankan
Buka langsung file `index.html` di browser, atau aktifkan **GitHub Pages** melalui *Settings > Pages > Branch: main* untuk menjadikannya website publik.
